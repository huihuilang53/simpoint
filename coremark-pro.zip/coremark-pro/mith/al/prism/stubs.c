#include <time.h>

int clock_gettime (clockid_t c, struct timespec *p) {
	return 0;
}
